/**
 * Delete category response type.
 * Since the API returns 204 No Content, this type is empty.
 */
export type TDeleteCategoryResponse = void;
