import {
  ArgumentsHost,
  Catch,
  ExceptionFilter,
  HttpException,
  HttpStatus,
  Logger,
} from '@nestjs/common';
import { HttpAdapterHost } from '@nestjs/core';
import { AxiosError } from 'axios';

@Catch()
export class CatchEverythingFilter implements ExceptionFilter {
  constructor(private readonly httpAdapterHost: HttpAdapterHost) {}

  catch(exception: unknown, host: ArgumentsHost): void {
    Logger.error(exception);
    console.error('exception: ', exception);
    const { httpAdapter } = this.httpAdapterHost;
    const ctx = host.switchToHttp();

    let httpStatus: number = HttpStatus.INTERNAL_SERVER_ERROR;
    let message = 'Internal Server Error';
    let errors = null;

    if (exception instanceof HttpException) {
      httpStatus = exception.getStatus();
      const errorResponse = exception.getResponse();

      if (Array.isArray(errorResponse)) {
        // Handle validation errors
        errors = errorResponse;
        message = 'Validation failed';
      } else {
        message =
          typeof errorResponse === 'string'
            ? errorResponse
            : (errorResponse as any).message || message;
      }
    }

    if (
      exception instanceof AxiosError &&
      exception.response?.status !== undefined
    ) {
      httpStatus = exception.response.status;
    }

    const responseBody = {
      statusCode: httpStatus,
      timestamp: new Date().toISOString(),
      path: httpAdapter.getRequestUrl(ctx.getRequest()),
      message,
      ...(errors && { errors }),
    };

    httpAdapter.reply(ctx.getResponse(), responseBody, httpStatus);
  }
}
