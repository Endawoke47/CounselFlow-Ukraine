import {
  BadRequestException,
  HttpException,
  HttpStatus,
  Logger,
} from '@nestjs/common';
import axios from 'axios';
import { CreateAuth0UserDto } from 'src/modules/auth0/auth0.dto';
import { v4 as uuidv4 } from 'uuid';
import { configService, Env } from './config.service';

export class Auth0Client {
  private managementToken: string | null = null;
  private tokenExpiry: number = 0;
  private readonly auth0Domain: string;
  private readonly clientId: string;
  private readonly clientSecret: string;
  private readonly auth0ManagementScopes: string[] = [
    'create:users read:users update:users delete:users',
    'create:users_app_metadata read:users_app_metadata update:users_app_metadata delete:users_app_metadata',
  ]; // Auth0 Dashboard > APIs > Auth0 Management API > Permissions tab
  private readonly axiosInstance = axios.create();

  constructor() {
    this.auth0Domain = configService.get(Env.AUTH0_DOMAIN);
    this.clientId = configService.get(Env.AUTH0_CLIENT_ID);
    this.clientSecret = configService.get(Env.AUTH0_CLIENT_SECRET);

    this.axiosInstance.interceptors.request.use(
      config => {
        // Check if the request already has a Request ID; if not, generate one
        const requestId = config.headers['X-Request-ID'] || uuidv4();
        config.headers['X-Request-ID'] = requestId; // Ensure it's attached to headers

        // Attach metadata for logging
        (config as any).metadata = {
          requestId,
          startTime: new Date().getTime(),
        };

        Logger.log(
          `Auth0 [${requestId}] ⏩ Request: ${config.method?.toUpperCase()} ${config.url}`,
        );
        if (config.data) {
          Logger.log(
            `Auth0 [${requestId}] 📦 Payload: ${JSON.stringify(config.data)}`,
          );
        }

        return config;
      },
      error => {
        Logger.error(`Auth0 🚨 Request Error ${JSON.stringify(error)}`);
        return Promise.reject(error);
      },
    );

    this.axiosInstance.interceptors.response.use(
      response => {
        const metadata = (response.config as any).metadata;
        const endTime = new Date().getTime();
        const processingTime = endTime - metadata.startTime;

        Logger.log(
          `Auth0 [${metadata.requestId}] ✅ Response: ${response.status} - Time: ${processingTime}ms`,
        );
        Logger.log(
          `Auth0 [${metadata.requestId}] ✅ Response data: ${JSON.stringify(response.data, null, 4)}`,
        );

        return response;
      },
      error => {
        if (error.config) {
          const metadata = (error.config as any).metadata;
          const endTime = new Date().getTime();
          const processingTime = metadata
            ? endTime - metadata.startTime
            : 'Unknown';

          Logger.error(
            `Auth0 [${metadata?.requestId}] ❌ Error ${JSON.stringify(axios.isAxiosError(error) ? error.response?.data : error)} - Time: ${processingTime}ms`,
          );
        }
        return Promise.reject(error);
      },
    );
  }

  private async getManagementToken(): Promise<string> {
    const currentTime = Math.floor(Date.now() / 1000); // Get current time in seconds

    if (this.managementToken && currentTime < this.tokenExpiry) {
      return this.managementToken; // Return cached token
    }

    try {
      const response = await this.axiosInstance.post(
        `https://${this.auth0Domain}/oauth/token`,
        {
          client_id: this.clientId,
          client_secret: this.clientSecret,
          audience: `https://${this.auth0Domain}/api/v2/`,
          grant_type: 'client_credentials',
          scope: this.auth0ManagementScopes.join(' '),
        },
      );

      this.managementToken = response.data.access_token;
      if (this.managementToken === null) {
        throw new Error('No access token found');
      }
      this.tokenExpiry = currentTime + response.data.expires_in - 60; // Subtract 60 sec buffer

      return this.managementToken;
    } catch (error) {
      Logger.error(
        `Error fetching Auth0 Management Token: ${JSON.stringify(error)}`,
      );
      throw new HttpException(
        'Failed to retrieve Auth0 token',
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }

  async createUser(body: CreateAuth0UserDto): Promise<any> {
    const response = await this.axiosInstance.post(
      `https://${this.auth0Domain}/api/v2/users`,
      JSON.stringify(body),
      {
        headers: {
          Authorization: `Bearer ${await this.getManagementToken()}`,
          'Content-Type': 'application/json',
          Accept: 'application/json',
        },
      },
    );
    return response.data;
  }

  async getUsers(): Promise<any> {
    const response = await this.axiosInstance.get(
      `https://${this.auth0Domain}/api/v2/users`,
      {
        headers: {
          Authorization: `Bearer ${await this.getManagementToken()}`,
        },
      },
    );
    return response.data;
  }

  async getUser(userId: number): Promise<any> {
    const response = await this.axiosInstance.get(
      `https://${this.auth0Domain}/api/v2/users/${userId}`,
      {
        headers: { Authorization: `Bearer ${await this.getManagementToken()}` },
      },
    );
    return response.data;
  }

  async login(email: string, password: string) {
    try {
      const response = await this.axiosInstance.post<{
        access_token: string;
        id_token: string;
        scope: string;
        expires_in: number;
        token_type: string;
      }>(`https://${this.auth0Domain}/oauth/token`, {
        grant_type: 'password',
        // grant_type: 'refresh_token',
        username: email,
        password,
        client_id: this.clientId,
        client_secret: this.clientSecret,
        audience: configService.get(Env.AUTH0_AUDIENCE),
        scope: 'openid profile email offline_access',
        connection: 'Username-Password-Authentication',
      });

      return response.data;
    } catch {
      throw new BadRequestException('Invalid email or password');
    }
  }
}

export const auth0Client = new Auth0Client();
