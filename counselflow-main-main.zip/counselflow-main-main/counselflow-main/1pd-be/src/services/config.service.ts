import { TypeOrmModuleOptions } from '@nestjs/typeorm';
import 'dotenv/config';
import { join } from 'path';
import { DataSourceOptions } from 'typeorm';
import { CustomNamingStrategy } from '../config/naming-strategy';

export enum Env {
  POSTGRES_HOST = 'POSTGRES_HOST',
  POSTGRES_PORT = 'POSTGRES_PORT',
  POSTGRES_USER = 'POSTGRES_USER',
  POSTGRES_PASSWORD = 'POSTGRES_PASSWORD',
  POSTGRES_DATABASE = 'POSTGRES_DATABASE',
  RUN_MIGRATIONS = 'RUN_MIGRATIONS',
  AUTH0_DOMAIN = 'AUTH0_DOMAIN',
  AUTH0_CLIENT_ID = 'AUTH0_CLIENT_ID',
  AUTH0_CLIENT_SECRET = 'AUTH0_CLIENT_SECRET',
  AUTH0_AUDIENCE = 'AUTH0_AUDIENCE',
  NODE_ENV = 'NODE_ENV', // TEST, DEV, PROD
  JWT_SECRET = 'JWT_SECRET',
  APP_URL = 'APP_URL',
  ADMIN_COMPANY_USER = 'ADMIN_COMPANY_USER',
  ADMIN_COMPANY_PASS = 'ADMIN_COMPANY_PASS',
  ADMIN_COMPANY_NAME = 'ADMIN_COMPANY_NAME',
  // AWS S3 configuration
  UPLOADS_AWS_REGION = 'UPLOADS_AWS_REGION',
  UPLOADS_AWS_ACCESS_KEY_ID = 'UPLOADS_AWS_ACCESS_KEY_ID',
  UPLOADS_AWS_SECRET_ACCESS_KEY = 'UPLOADS_AWS_SECRET_ACCESS_KEY',
  UPLOADS_AWS_S3_DEFAULT_BUCKET_NAME = 'UPLOADS_AWS_S3_DEFAULT_BUCKET_NAME', // Default bucket
  UPLOADS_STORAGE_PROVIDER = 'UPLOADS_STORAGE_PROVIDER', // 'local' or 's3'
}

class ConfigService {
  constructor(private env: { [k: string]: string | undefined }) {}

  private getValue(key: Env): string {
    const value = this.env[key];
    if (!value) {
      throw new Error(`config error - missing env.${key}`);
    }

    return value;
  }

  public ensureValues(keys: Env[]) {
    keys.forEach(k => this.getValue(k));
    return this;
  }

  public get(envName: Env): string {
    return this.getValue(envName);
  }

  public getTypeOrmConfig(): TypeOrmModuleOptions | DataSourceOptions {
    return {
      type: 'postgres',
      host: this.getValue(Env.POSTGRES_HOST),
      port: parseInt(this.getValue(Env.POSTGRES_PORT)),
      username: this.getValue(Env.POSTGRES_USER),
      password: this.getValue(Env.POSTGRES_PASSWORD),
      database: this.getValue(Env.POSTGRES_DATABASE),
      synchronize: false, // we can not use this, because we populate the database with data
      logging: false,
      migrationsRun: this.getValue(Env.RUN_MIGRATIONS) === 'true',
      entities: [join(__dirname, '..', '**', '*.entity.{ts,js}')],
      migrationsTableName: 'migrations',
      migrations: [join(__dirname, '..', 'migrations', '*{.ts,.js}')],
      ssl: this.getValue(Env.NODE_ENV) === 'production',
      namingStrategy: new CustomNamingStrategy(),
      schema: 'public',
    };
  }
}

const configService = new ConfigService(process.env).ensureValues(
  Object.values(Env),
);

export { configService };
