import { defineBackend } from '@aws-amplify/backend';

const backend = defineBackend({
  // Your backend configuration will go here
});

export default backend;
