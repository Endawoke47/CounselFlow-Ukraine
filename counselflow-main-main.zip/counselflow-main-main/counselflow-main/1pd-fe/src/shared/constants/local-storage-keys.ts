export const LOCAL_STORAGE_KEYS = {
  LOGIN_STATE: 'login-state',
};
