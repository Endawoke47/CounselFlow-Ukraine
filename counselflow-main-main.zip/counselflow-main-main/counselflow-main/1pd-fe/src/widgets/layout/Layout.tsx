import { useQueryErrorResetBoundary } from '@tanstack/react-query';
import { ReactNode } from 'react';
import { ErrorBoundary } from 'react-error-boundary';

import AppSidebar from '../AppSidebar/AppSidebar';

import { SidebarProvider } from '@/shared/ui/Sidebar';
import ErrorFallback from '@/widgets/error/ErrorFallback';

const Layout = ({ children }: { children: ReactNode }) => {
  const { reset } = useQueryErrorResetBoundary();

  return (
    <ErrorBoundary FallbackComponent={ErrorFallback} onReset={reset}>
      <SidebarProvider>
        <AppSidebar>
          {children}
        </AppSidebar>
      </SidebarProvider>
    </ErrorBoundary>
  );
};

export default Layout;
