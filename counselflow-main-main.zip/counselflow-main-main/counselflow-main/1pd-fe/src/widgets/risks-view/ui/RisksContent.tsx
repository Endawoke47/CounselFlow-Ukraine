import Table from '@/shared/ui/Table/Table';
import { columns } from './tableColumns';
import { useFetchRisks } from '@/entities/risks/hooks';
import { Separator } from '@/shared/ui/Separator';

export const RisksContent = () => {
  const { data, isLoading, error } = useFetchRisks();

  if (isLoading) {
    return <div>Loading...</div>;
  }

  if (error) {
    return <div>Error loading risks</div>;
  }

  return (
    <div className="p-10">
      <div className="text-xl font-bold text-teal-900">RISKS</div>
      <Separator className="my-4 bg-black"/>
      <Table
        columns={columns}
        rowData={data?.data ?? []}
        rowSelection="multiple"
      />
    </div>
  );
};
