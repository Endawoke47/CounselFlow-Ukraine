import { ColDef } from 'ag-grid-community';

export const columns: ColDef<any>[] = [
  {
    headerName: 'Name',
    field: 'name',
  },
  {
    headerName: 'Matter',
    field: 'matter',
  },
  {
    headerName: 'Score',
    field: 'score',
  },
  {
    headerName: 'Type',
    field: 'type',
  },
  {
    headerName: 'Company',
    field: 'company',
  }
];
