import { useMutation } from '@tanstack/react-query';
import { useNavigate } from '@tanstack/react-router';
import { toast } from 'react-toastify';
import { httpClient } from '@/entities/api/http.client';
import { APP_ROUTES } from '@/entities/api/routes';

type LoginRequestProps = {
  email: string;
  password: string;
};

type LoginResponseProps = {
  message: string;
};

export const useLogin = () => {
  const navigate = useNavigate();
  return useMutation({
    mutationFn: async (data: LoginRequestProps) => {
      return httpClient.post<LoginRequestProps, LoginResponseProps>(
        APP_ROUTES.LOGIN,
        data
      );
    },
    onSuccess: () => navigate({ to: '/dashboard' }),
    onError: (error) => toast.error(error.message),
  });
};
