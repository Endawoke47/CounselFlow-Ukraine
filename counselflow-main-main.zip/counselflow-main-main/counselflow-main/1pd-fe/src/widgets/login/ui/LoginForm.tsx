import { useState } from 'react';
import { useLogin } from '@/widgets/login/hooks/useLogin';

export const LoginForm = () => {
  const { mutateAsync } = useLogin();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const onSubmit = async () => {
    await mutateAsync({ email, password });
  };

  return (
    <div className="w-full max-w-md">
      <div className="mb-4">
        <input
          type="email"
          className="shadow-sm focus:ring-teal-500 focus:border-teal-500 block w-full sm:text-sm border-gray-300 bg-slate-200 rounded-md py-3 px-4 text-center"
          placeholder="Email address"
          required
          onChange={(e) => setEmail(e.target.value)}
        />
      </div>
      <div className="mb-6">
        <input
          type="password"
          className="shadow-sm focus:ring-teal-500 focus:border-teal-500 block w-full sm:text-sm border-gray-300 bg-slate-200 rounded-md py-3 px-4 text-center"
          placeholder="Password"
          required
          onChange={(e) => setPassword(e.target.value)}
        />
      </div>
      <div>
        <button
          className="bg-teal-700 hover:bg-teal-600 text-white font-semibold py-3 px-6 rounded-md w-full focus:outline-none focus:ring-2 focus:ring-teal-500 focus:ring-offset-2"
          onClick={onSubmit}
        >
          LOG IN
        </button>
      </div>
    </div>
  );
};
