import Table from '@/shared/ui/Table/Table';
import { useFetchMatters } from '@/widgets/matters-view/hooks/useFetchMatters';
import { columns } from '@/widgets/matters-view/ui/tableColumns';
import { Separator } from '@/shared/ui/Separator';
import { useState } from 'react';
import Drawer from '@/shared/ui/Drawer/Drawer';
import { Button } from '@/shared/ui';
import { Link } from '@tanstack/react-router';

export const MattersContent = () => {
  const { data, isLoading, error } = useFetchMatters();
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);
  const [selectedIds, setSelectedIds] = useState<string[]>();

  const handleRowSelect = (ids: string[]) => {
    setIsDrawerOpen(true);
    setSelectedIds(ids);
  };

  if (isLoading) {
    return <div>Loading...</div>;
  }

  if (error) {
    return <div>Error loading matters</div>;
  }

  return (
    <div className="p-10 w-full">
      <div className="flex justify-between items-center py-2">
        <div className="text-xl font-bold text-teal-900">MATTERS</div>
        <Link to={'/addMatter'}>
          <Button className="px-10" variant="outline">
            Add
          </Button>
        </Link>
      </div>
      <Separator className="my-4 bg-black" />
      <div className="border min-h-80">
        <Table
          columns={columns}
          rowData={data?.data ?? []}
          rowSelection="multiple"
          setSelectedIds={handleRowSelect}
        />
        <Drawer
          isOpen={isDrawerOpen}
          onClose={() => setIsDrawerOpen(false)}
          className="max-w-[700px]"
        >
          OK
        </Drawer>
      </div>
    </div>
  );
};
