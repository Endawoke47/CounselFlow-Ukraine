import { useQuery } from '@tanstack/react-query';

import { mattersClient } from '@/entities/matters/api/matters.client';

export const useFetchMatters = () => {
  return useQuery({
    queryKey: ['matters'],
    queryFn: mattersClient.getMatters,
  });
};
