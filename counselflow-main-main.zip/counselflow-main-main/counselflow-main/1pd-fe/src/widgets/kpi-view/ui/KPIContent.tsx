import { useFetchRisks } from '@/entities/risks/hooks';
import { Separator } from '@/shared/ui/Separator';

export const KPIContent = () => {
  const { data, isLoading, error } = useFetchRisks();

  if (isLoading) {
    return <div>Loading...</div>;
  }

  if (error) {
    return <div>Error loading KPIs</div>;
  }

  return (
    <div className="p-10 w-full">
      <div className="text-xl font-bold text-teal-900">KPIs</div>
      <Separator className="my-4 bg-black"/>
      <div className="flex flex-col gap-4 border min-h-80">
        <Separator className="h-10 bg-gray-300"/>
        <div className="flex justify-between items-center px-4">
          <div>Risks this month</div>
          <div>12</div>
        </div>
        <div className="flex justify-between items-center px-4">
          <div>No of pending tasks</div>
          <div>67</div>
        </div>
      </div>
    </div>
  );
};
