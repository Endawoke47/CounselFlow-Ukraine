export { KPIContent } from './KPIContent';

