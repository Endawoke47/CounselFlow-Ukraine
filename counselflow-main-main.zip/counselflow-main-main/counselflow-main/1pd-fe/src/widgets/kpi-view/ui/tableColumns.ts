import { ColDef } from 'ag-grid-community';

export const columns: ColDef<any>[] = [
  {
    headerName: '',
    field: 'name',
  },
];
