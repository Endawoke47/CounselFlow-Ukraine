import Table from '@/shared/ui/Table/Table';
import { columns } from './tableColumns';
import { useFetchRisks } from '@/entities/risks/hooks';
import { Separator } from '@/shared/ui/Separator';
import { GenerateReport } from '@/widgets/generate-report/ui';
import { Button } from '@/shared/ui';
import { Link } from '@tanstack/react-router';
import Drawer from '@/shared/ui/Drawer/Drawer';
import { useState } from 'react';
import { RiskDrawer } from '@/widgets/risk-drawer/ui';

export const MainRisksContent = () => {
  const { data, isLoading, error } = useFetchRisks();
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);
  const [selectedIds, setSelectedIds] = useState<string[]>();

  const handleRowSelect = (ids: string[]) => {
    setIsDrawerOpen(true);
    setSelectedIds(ids);
  };

  if (isLoading) {
    return <div>Loading...</div>;
  }

  if (error) {
    return <div>Error loading risks</div>;
  }

  return (
    <div className="p-10">
      <div className="flex justify-between items-center py-2">
        <div className="text-xl font-bold text-teal-900">RISKS</div>
        <Link to={'/addRisk'}>
          <Button className="px-10" variant="outline">
            Add
          </Button>
        </Link>
      </div>
      <Separator className="my-4 bg-black" />
      <Table
        columns={columns}
        rowData={data?.data ?? []}
        rowSelection="multiple"
        setSelectedIds={handleRowSelect}
      />
      <Drawer
        isOpen={isDrawerOpen}
        onClose={() => setIsDrawerOpen(false)}
        className="max-w-[700px]"
      >
        <RiskDrawer id={selectedIds as unknown as number} />
      </Drawer>
      <GenerateReport />
    </div>
  );
};
