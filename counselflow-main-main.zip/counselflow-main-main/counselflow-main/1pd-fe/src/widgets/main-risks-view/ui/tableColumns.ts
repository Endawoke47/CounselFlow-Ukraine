import { ColDef } from 'ag-grid-community';

export const columns: ColDef<any>[] = [
  {
    headerName: 'Name',
    field: 'name',
  },
  {
    headerName: 'Description',
    field: 'description',
  },
  {
    headerName: 'Score',
    field: 'score',
  },
  {
    headerName: 'Type',
    field: 'type',
  },
  {
    headerName: 'Owner',
    field: 'owner',
  }
];
