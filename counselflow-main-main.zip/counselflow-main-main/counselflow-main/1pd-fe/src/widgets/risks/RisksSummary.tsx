import { useState } from 'react';

import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/shared/ui/Tabs';

type RisksData = {
  all: number;
  high: number;
  medium: number;
  low: number;
  draft: number;
};

const risksByTab: Record<string, RisksData> = {
  'statuses-tab': {
    all: 75,
    high: 16,
    medium: 22,
    low: 17,
    draft: 20,
  },
  'categories-tab': {
    all: 90,
    high: 35,
    medium: 29,
    low: 13,
    draft: 13,
  },
  'entities-tab': {
    all: 100,
    high: 35,
    medium: 30,
    low: 22,
    draft: 13,
  },
};

const SegmentedBar = ({ data }: { data: RisksData }) => {
  const getWidthPercentage = (value: number) =>
    data.all ? `${(value / data.all) * 100}%` : '0%';

  return (
    <div className="mt-4">
      <div className="text-lg text-gray-700">
        All Risks: <span className="font-bold">{data.all}</span>
      </div>
      <div className="flex w-full h-10 mt-2 overflow-hidden gap-2">
        <div
          className="bg-red-500 text-white flex items-center justify-center text-sm font-medium"
          style={{ width: getWidthPercentage(data.high) }}
        >
          {data.high > 0 && `High: ${data.high}`}
        </div>
        <div
          className="bg-yellow-500 text-white flex items-center justify-center text-sm font-medium"
          style={{ width: getWidthPercentage(data.medium) }}
        >
          {data.medium > 0 && `Medium: ${data.medium}`}
        </div>
        <div
          className="bg-green-500 text-white flex items-center justify-center text-sm font-medium"
          style={{ width: getWidthPercentage(data.low) }}
        >
          {data.low > 0 && `Low: ${data.low}`}
        </div>
        <div
          className="bg-gray-400 text-white flex items-center justify-center text-sm font-medium"
          style={{ width: getWidthPercentage(data.draft) }}
        >
          {data.draft > 0 && `Drafts: ${data.draft}`}
        </div>
      </div>
    </div>
  );
};

export const RisksSummary = () => {
  const [selectedTab, setSelectedTab] = useState('statuses-tab');
  const [expanded, setExpanded] = useState(true);
  return (
    <div className="bg-dashboard-lighter-blue rounded-lg p-6 m-4">
      <div className="flex items-center justify-between gap-2 text-gray-800 font-semibold text-lg">
        <div className="flex items-center gap-2">
          <img src="/icons/sidebar/flags.png" alt="flag" className="w-5 h-5" />
          <span>RISK SUMMARY</span>
        </div>
        <img
          src="/icons/minus-square.png"
          onClick={() => setExpanded(!expanded)}
          alt="minus"
          className="w-[16px] h-[16px] cursor-pointer hover:opacity-[0.5]"
        />
      </div>

      {expanded && (
        <Tabs
          value={selectedTab}
          onValueChange={setSelectedTab}
          defaultValue="statuses-tab"
          className="w-full mt-4"
        >
          <TabsList className="flex gap-6 border-b border-gray-300">
            <TabsTrigger
              value="statuses-tab"
              className="px-4 py-2 text-gray-600 font-medium border-b-2 border-transparent data-[state=active]:text-blue-600 data-[state=active]:border-blue-600"
            >
              Risks Statuses
            </TabsTrigger>
            <TabsTrigger
              value="categories-tab"
              className="px-4 py-2 text-gray-600 font-medium border-b-2 border-transparent data-[state=active]:text-blue-600 data-[state=active]:border-blue-600"
            >
              Risk by Category
            </TabsTrigger>
            <TabsTrigger
              value="entities-tab"
              className="px-4 py-2 text-gray-600 font-medium border-b-2 border-transparent data-[state=active]:text-blue-600 data-[state=active]:border-blue-600"
            >
              Risk by Entity
            </TabsTrigger>
          </TabsList>

          <TabsContent value="statuses-tab">
            <SegmentedBar data={risksByTab[selectedTab]} />
          </TabsContent>
          <TabsContent value="categories-tab">
            <SegmentedBar data={risksByTab[selectedTab]} />
          </TabsContent>
          <TabsContent value="entities-tab">
            <SegmentedBar data={risksByTab[selectedTab]} />
          </TabsContent>
        </Tabs>
      )}
    </div>
  );
};
