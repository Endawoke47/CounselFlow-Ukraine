import { useFetchMatter } from '@/entities/matters/hooks/useFetchMatter';

export const MatterDrawer = ({ id }: { id?: string }) => {
  const {data} = useFetchMatter(id as string);

  return (<div className="px-8">
    <h1>MATTER</h1>
    <div className="text-teal-900 text-xl font-bold my-3">{data?.name}</div>
    <div className="text-teal-900 font-bold mt-6">Description</div>
    <div>{data?.description}</div>
  </div>);
};
