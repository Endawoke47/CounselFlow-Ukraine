import { AlertTriangle, Loader2, TrendingUp } from 'lucide-react'; // Added TrendingUp icon
import React from 'react';

import { useFetchKpis } from '@/features/view-kpis';

// Define props interface to accept className
interface KpiSummaryProps {
  className?: string;
}

export const KpiSummary: React.FC<KpiSummaryProps> = ({ className }) => {
  const { data: kpiData, isLoading, error } = useFetchKpis();

  return (
    // Apply flex-col to allow content centering if desired
    <div
      className={`w-full bg-white rounded-lg shadow p-6 flex flex-col ${className || ''}`}
    >
      <h3 className="text-2xl font-bold mb-2 flex-shrink-0">
        New Risks This Month
      </h3>
      <div className="flex-grow flex items-center justify-center">
        {' '}
        {/* Center content vertically and horizontally */}
        {isLoading && (
          <Loader2 className="animate-spin h-8 w-8 text-gray-400" />
        )}
        {error && (
          <div className="flex flex-col items-center text-red-600">
            <AlertTriangle className="h-6 w-6 mb-1" />
            <span className="text-sm">Error</span>
          </div>
        )}
        {!isLoading && !error && kpiData !== undefined && (
          <div className="flex items-center gap-4">
            <TrendingUp className="h-10 w-10 text-blue-500" />
            <span className="text-5xl font-bold text-gray-800">
              {kpiData.newHighCriticalRisksThisMonth}
            </span>
          </div>
        )}
      </div>
    </div>
  );
};

export default KpiSummary;
