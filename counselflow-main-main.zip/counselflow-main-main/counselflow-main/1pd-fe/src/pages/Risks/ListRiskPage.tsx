import Layout from '@/widgets/layout/Layout';
import { MainRisksContent } from '@/widgets/main-risks-view/ui';

export default function ListRiskPage() {
  return (
    <Layout>
        <MainRisksContent />
    </Layout>
  );
}
