export { LoginPage } from './LoginPage';

