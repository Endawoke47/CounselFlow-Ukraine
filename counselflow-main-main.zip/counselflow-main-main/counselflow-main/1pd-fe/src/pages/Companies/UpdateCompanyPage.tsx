import { UpdateCompany } from '@/features/manage-companies/ui';
import Layout from '@/widgets/layout/Layout';

export const UpdateCompanyPage = () => {
  return (
    <Layout>
      <UpdateCompany />
    </Layout>
  );
}
