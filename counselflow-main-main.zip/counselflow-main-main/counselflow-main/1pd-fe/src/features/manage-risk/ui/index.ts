export { default as DeleteRisk } from './DeleteRisk';
export { default as ManageRisk } from './ManageRisk';
export { default as RiskList } from './RiskList';
export { default as DisplayRisk } from './DisplayRisk';
